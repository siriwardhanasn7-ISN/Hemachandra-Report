const { app, BrowserWindow, shell } = require("electron");

const APP_URL = "https://siriwardhanasn7-isn.github.io/Hemachandra-Report/";

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 960,
    minWidth: 1024,
    minHeight: 720,
    show: false,
    autoHideMenuBar: true,
    title: "Hemachandra Gem Lab",
    backgroundColor: "#f4f6f9",
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webviewTag: false
    }
  });

  const appOrigin = new URL(APP_URL).origin;

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https://") && !url.startsWith(appOrigin)) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });

  win.webContents.on("will-navigate", (event, url) => {
    try {
      if (new URL(url).origin !== appOrigin) {
        event.preventDefault();
        if (url.startsWith("https://")) shell.openExternal(url);
      }
    } catch {
      event.preventDefault();
    }
  });

  win.once("ready-to-show", () => win.show());
  win.loadURL(APP_URL);

  win.webContents.on("did-fail-load", (_event, errorCode, errorDescription, validatedURL) => {
    if (errorCode === -3) return;
    console.error("Application page failed to load:", errorCode, errorDescription, validatedURL);
  });
}

app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
