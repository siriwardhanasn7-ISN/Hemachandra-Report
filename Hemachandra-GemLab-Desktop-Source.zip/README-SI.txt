HEMACHANDRA GEM LAB - WINDOWS EXE BUILD

මෙය Windows 10/11 (64-bit) සඳහා Installer EXE එකක් සාදන Electron project එකකි.

වැදගත්:
- EXE එක විවෘත කළ විට ඔබගේ දැනට තිබෙන GitHub Pages Web Application එකම විවෘත වේ.
- App එකට Internet connection අවශ්‍යයි.
- වාර්තා Firebase Firestore එකේම Save වන නිසා දැනට තිබෙන reports අහිමි නොවේ.
- QR Code එකේ URL එක දැනට තිබෙන public website එකට යන නිසා Mobile එකෙන් Scan කළ විට එම report එක View Only ලෙස පෙන්විය හැක.
- QR එක ක්‍රියා කිරීමට GitHub Pages website එක සහ Firebase Firestore public read rules ක්‍රියාත්මක විය යුතුය.
- මෙය Web Application එකේ design හෝ fields වෙනස් නොකරන Desktop wrapper එකකි.

BUILD:
GitHub repository එකට මෙම ZIP එක upload කර, වෙනම දෙන build-windows-exe.yml file එක
.github/workflows/ folder එකට දමන්න. ඉන්පසු GitHub > Actions > Build Windows EXE >
Run workflow තෝරන්න. Build අවසන් වූ විට Artifacts යටතේ Windows installer එක ලැබේ.

Generated installer:
Hemachandra-Gem-Lab-Setup-1.0.0.exe
